@extends('backend.layout.template')
@section('body_content')
<div id="kt_app_content" class="app-content flex-column-fluid">
   <!--begin::Content container-->
   <div id="kt_app_content_container" class="app-container container-xxl">
      <div class="row g-10">
            <div class="card card-flush">
            <div class="card-body">
               <table id="datatable" class="table table-hover table-striped table-bordered" style="width:100%">
                  <thead>
                     <tr>
                        <th>#Id</th>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>IP Address</th>
                     </tr>
                  </thead>
                  <tbody>
                     @foreach ($attendances as $attendance)
                     @if(Auth::user()->id == $attendance->user_id)
                     <tr>
                        <td>
                           <span class="fw-bold">{{$attendance->id}}</span>
                        </td>
                        <td>
                           <span class="fw-bold ms-3">
                           {{Auth::user()->name}}
                           </span>
                        </td>
                        <td>
                           {{$attendance->created_at->format('d-F-Y')}}
                        </td>
                        <td>
                           {{$attendance->created_at->format('h:i:s A')}}
                        </td>
                        <td>

                           {{-- diffrent time  --}}
                           @php
                              $office_in_time = "11:15:00";
                              $am             = "am";
                              $user_in_time   = $attendance->created_at->format('h:i:s');
                              $user_am        = $attendance->created_at->format('a');

                              // diffrent time 
                              $in          = '11:15:00'; 
                              $user_in     = $user_in_time;              
                              $in_count    = new DateTime($in); 
                              $count_diff  = $in_count->diff(new DateTime($user_in)); 

                           @endphp

                           @if($attendance->status == 1)
                              @if($office_in_time >= $user_in_time AND $am == $user_am)
                                    <div class="text-success">
                                       <strong class="badge badge-success"> On Time Present </strong>
                                    </div>
                                    @else
                                    <div class="text-danger"> 
                                       @php
                                          echo $count_diff->h.' Hours '; 
                                          echo $count_diff->i.' Minutes '; 
                                          echo $count_diff->s.' Seconds ';
                                       @endphp
                                       <strong class="badge badge-danger"> You are Late </strong>
                                    </div>
                              @endif
                           @endif

                     {{-- office out time  --}}
                           @php
                              $office_out_time = "07:00:00";
                              $pm              = "pm";
                              $user_out_time   = $attendance->created_at->format('h:i:s');
                              $user_pm         = $attendance->created_at->format('a');

                              // diffrent time 
                              $out       = '07:00:00'; 
                              $user_out  = $user_in_time; 
                              $out_count = new DateTime($out); 
                              $out_diff  = $out_count->diff(new DateTime($user_out)); 
                           @endphp

                           @if($attendance->status == 2)
                              @if($office_out_time <= $user_out_time AND $pm == $user_pm)
                                 <div class="text-success">
                                    <strong class="badge badge-success"> On Time Leave </strong>
                                 </div>
                                 @else
                                 <div class="text-danger">
                                    @php
                                    echo $out_diff->h.' Hours '; 
                                    echo $out_diff->i.' Minutes '; 
                                    echo $out_diff->s.' Seconds ';
                                 @endphp
                                  <strong class="badge badge-danger"> Early Leave </strong>
                                 </div>
                              @endif
                           @endif
                        </td>
                        <td>
                           <div class="badge badge-light-primary">{{$attendance->ip_address}}</div>
                        </td>
                     </tr>
                     @else
                     @endif
                     @endforeach
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      </div>
   </div>
@endsection